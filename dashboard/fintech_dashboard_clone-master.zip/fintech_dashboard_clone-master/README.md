# Fintech Dashboard Clone

This repository is based on converting the mockup below into a flutter app.

![app](assets/dribble.png)

## Screenshots of our project

Desktop: 

![app](assets/desktop.png)

Mobile: 

![app](assets/mobile.png)
