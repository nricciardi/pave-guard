package com.example.fintech_dashboard_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
