// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'env.dart';

// **************************************************************************
// EnviedGenerator
// **************************************************************************

class _Env {
  static const apiKey = 'AIzaSyCpIk1nUIviH0ViMVBiLx9pzkHqi4CjfCw';
  static const appId = '1:607611285447:web:ff201bac1c9e929b59f3e';
  static const messagingSenderId = '607611285447';
  static const projectId = 'flutter-admin-dashboard-f75ed';
  static const authDomain = 'flutter-admin-dashboard-f75ed.firebaseapp.com';
  static const storageBucket = 'flutter-admin-dashboard-f75ed.appspot.com';
}
